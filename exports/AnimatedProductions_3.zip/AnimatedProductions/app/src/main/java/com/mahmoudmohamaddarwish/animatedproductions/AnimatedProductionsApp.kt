package com.mahmoudmohamaddarwish.animatedproductions

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AnimatedProductionsApp : Application()