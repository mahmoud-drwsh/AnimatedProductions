package com.mahmoudmohamaddarwish.animatedproductions.screens.details

enum class DetailsActivityTestTags {
    ROOT_COMPOSABLE,
    ROOT_FAVORITE_ICON,
    RATING_AND_LANGUAGE_ROW,
    BACKDROP_IMAGE,
    POSTER_IMAGE,
    TITLE_TEXT,
    OVERVIEW_TEXT,
    LOADING_INDICATOR,
    ERROR_MESSAGE,
}