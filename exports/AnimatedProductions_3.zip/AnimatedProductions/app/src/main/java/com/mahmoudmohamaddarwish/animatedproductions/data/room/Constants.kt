package com.mahmoudmohamaddarwish.animatedproductions.data.room

object Constants {
    const val ID_COL_NAME = "_id"
}