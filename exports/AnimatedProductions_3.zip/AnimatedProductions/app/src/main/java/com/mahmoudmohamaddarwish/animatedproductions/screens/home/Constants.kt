package com.mahmoudmohamaddarwish.animatedproductions.screens.home

const val PRODUCTIONS_GRID_CELLS_NUMBER: Int = 2